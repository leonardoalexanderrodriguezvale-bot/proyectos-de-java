package juego.core;

public enum EstadoJuego {
    INICIO,
    JUGANDO,
    GOL,
    FALTA,
    PAUSADO,
    VICTORIA,
    DERROTA,
    TIEMPO_AGOTADO
}
