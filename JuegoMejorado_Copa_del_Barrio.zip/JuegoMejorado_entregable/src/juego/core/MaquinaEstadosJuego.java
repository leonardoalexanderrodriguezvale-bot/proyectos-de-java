package juego.core;

public class MaquinaEstadosJuego {
    private EstadoJuego estadoActual;
    private int framesEstado;
    private String mensajeTemporal;

    public MaquinaEstadosJuego() {
        estadoActual  = EstadoJuego.INICIO;
        framesEstado  = 0;
        mensajeTemporal = "";
    }

    public EstadoJuego getEstadoActual() { return estadoActual; }
    public String getMensajeTemporal()   { return mensajeTemporal; }

    public boolean permiteActualizarMundo() {
        return estadoActual == EstadoJuego.JUGANDO;
    }

    public void iniciarDesdeInicio() {
        if (estadoActual == EstadoJuego.INICIO) {
            cambiarEstado(EstadoJuego.JUGANDO);
            mensajeTemporal = "";
        }
    }

    public void alternarPausa() {
        if (estadoActual == EstadoJuego.JUGANDO) {
            cambiarEstado(EstadoJuego.PAUSADO);
        } else if (estadoActual == EstadoJuego.PAUSADO) {
            cambiarEstado(EstadoJuego.JUGANDO);
        }
    }

    public void reiniciar() {
        cambiarEstado(EstadoJuego.INICIO);
        framesEstado    = 0;
        mensajeTemporal = "";
    }

    public void procesarEventoJuego(EventoJuego evento) {
        switch (evento) {
            case GOL_LOCAL -> {
                cambiarEstado(EstadoJuego.GOL);
                framesEstado    = ConfiguracionJuego.FRAMES_MENSAJE_GOL;
                mensajeTemporal = "Golazo local";
            }
            case GOL_RIVAL -> {
                cambiarEstado(EstadoJuego.GOL);
                framesEstado    = ConfiguracionJuego.FRAMES_MENSAJE_GOL;
                mensajeTemporal = "Gol del rival";
            }
            case FALTA_A_FAVOR -> {
                cambiarEstado(EstadoJuego.FALTA);
                framesEstado    = ConfiguracionJuego.FRAMES_MENSAJE_FALTA;
                mensajeTemporal = "Falta a favor";
            }
            case FALTA_EN_CONTRA -> {
                cambiarEstado(EstadoJuego.FALTA);
                framesEstado    = ConfiguracionJuego.FRAMES_MENSAJE_FALTA;
                mensajeTemporal = "Falta en contra";
            }
            case VICTORIA -> {
                cambiarEstado(EstadoJuego.VICTORIA);
                mensajeTemporal = "";
            }
            case DERROTA -> {
                cambiarEstado(EstadoJuego.DERROTA);
                mensajeTemporal = "";
            }
            case TIEMPO_AGOTADO -> {
                cambiarEstado(EstadoJuego.TIEMPO_AGOTADO);
                mensajeTemporal = "";
            }
            default -> {}
        }
    }

    public void actualizar() {
        if (estadoActual == EstadoJuego.GOL || estadoActual == EstadoJuego.FALTA) {
            framesEstado--;
            if (framesEstado <= 0) {
                cambiarEstado(EstadoJuego.JUGANDO);
                mensajeTemporal = "";
            }
        }
    }

    private void cambiarEstado(EstadoJuego nuevoEstado) {
        estadoActual = nuevoEstado;
    }
}
