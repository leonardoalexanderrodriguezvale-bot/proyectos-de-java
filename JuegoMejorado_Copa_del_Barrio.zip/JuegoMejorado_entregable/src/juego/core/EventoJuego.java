package juego.core;

public enum EventoJuego {
    NINGUNO,
    GOL_LOCAL,
    GOL_RIVAL,
    FALTA_A_FAVOR,
    FALTA_EN_CONTRA,
    VICTORIA,
    DERROTA,
    TIEMPO_AGOTADO
}
