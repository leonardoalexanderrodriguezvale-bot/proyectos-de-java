package juego.ui;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;
import javax.swing.Timer;

import juego.core.ConfiguracionJuego;
import juego.core.EntradaJuego;
import juego.core.EventoJuego;
import juego.core.MaquinaEstadosJuego;
import juego.core.MotorJuego;
import juego.sonido.GestorSonido;
import juego.sonido.TipoSonido;

// Panel principal: recibe input, avanza la simulacion y delega el render.
public class PanelJuego extends JPanel implements KeyListener, ActionListener {
    private final Timer timer;
    private final EntradaJuego entrada;
    private final MaquinaEstadosJuego maquinaEstados;
    private final MotorJuego motor;
    private final RenderJuego renderizador;
    private final GestorSonido gestorSonido;

    public PanelJuego() {
        setPreferredSize(new Dimension(ConfiguracionJuego.ANCHO_PANEL, ConfiguracionJuego.ALTO_PANEL));
        setFocusable(true);
        addKeyListener(this);

        entrada         = new EntradaJuego();
        maquinaEstados  = new MaquinaEstadosJuego();
        motor           = new MotorJuego();
        renderizador    = new RenderJuego();
        gestorSonido    = new GestorSonido();

        timer = new Timer(1000 / ConfiguracionJuego.FPS, this);
        timer.start();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        renderizador.dibujarEscena(g, motor, maquinaEstados, motor.getFramesAnimacion());
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        maquinaEstados.actualizar();

        if (maquinaEstados.permiteActualizarMundo()) {
            EventoJuego evento = motor.actualizar(entrada);
            maquinaEstados.procesarEventoJuego(evento);
            if (evento != EventoJuego.NINGUNO) {
                entrada.limpiarMovimiento();
            }
        }
        reproducirSonidosPendientes();
        repaint();
    }

    @Override
    public void keyPressed(KeyEvent e) {
        int codigo = e.getKeyCode();

        if (codigo == KeyEvent.VK_ENTER) {
            maquinaEstados.iniciarDesdeInicio();
            gestorSonido.reproducir(TipoSonido.INICIO);
            return;
        }
        if (codigo == KeyEvent.VK_R) {
            motor.reiniciarPartido();
            maquinaEstados.reiniciar();
            entrada.limpiarMovimiento();
            gestorSonido.reproducir(TipoSonido.SAQUE);
            return;
        }
        if (codigo == KeyEvent.VK_P) {
            maquinaEstados.alternarPausa();
            if (!maquinaEstados.permiteActualizarMundo()) entrada.limpiarMovimiento();
            return;
        }
        if (maquinaEstados.permiteActualizarMundo()) {
            entrada.procesarPresion(codigo);
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        entrada.procesarLiberacion(e.getKeyCode());
    }

    @Override
    public void keyTyped(KeyEvent e) {}

    private void reproducirSonidosPendientes() {
        TipoSonido sonido;
        while ((sonido = motor.consumirSonidoPendiente()) != null) {
            gestorSonido.reproducir(sonido);
        }
    }
}
