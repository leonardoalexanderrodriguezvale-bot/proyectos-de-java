package juego.ui;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.RenderingHints;

import juego.core.ConfiguracionJuego;
import juego.core.EstadoJuego;
import juego.core.MaquinaEstadosJuego;
import juego.core.MotorJuego;
import juego.entidades.Jugador;

// Renderizador 2D puro: dibuja escena, HUD y overlays sin mutar la logica.
public class RenderJuego {

    public void dibujarEscena(Graphics g, MotorJuego motor, MaquinaEstadosJuego maquinaEstados, int frameAnimacion) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        dibujarFondo(g2, frameAnimacion);
        dibujarCancha(g2, frameAnimacion);
        dibujarDecoración(g2, frameAnimacion);

        motor.getBalon().dibujar(g2);
        motor.getMonedaEspecial().dibujar(g2);
        motor.getTurbo().dibujar(g2);

        for (Jugador local : motor.getLocales())  local.dibujar(g2);
        for (Jugador rival : motor.getRivales())  rival.dibujar(g2);
        dibujarEtiquetasJugadores(g2, motor);

        dibujarHUD(g2, motor);
        dibujarOverlayEstado(g2, maquinaEstados.getEstadoActual(), maquinaEstados.getMensajeTemporal(), motor);
        g2.dispose();
    }

    // ===================== FONDO =====================

    private void dibujarFondo(Graphics2D g, int f) {
        // Degradado nocturno de pizarra a morado oscuro.
        g.setPaint(new GradientPaint(0, 0, new Color(16, 14, 36), 0, ConfiguracionJuego.ALTO_PANEL, new Color(35, 20, 55)));
        g.fillRect(0, 0, ConfiguracionJuego.ANCHO_PANEL, ConfiguracionJuego.ALTO_PANEL);

        // Estrellas estaticas generadas deterministicamente.
        g.setColor(new Color(255, 255, 255, 60));
        int[] seedX = {120, 340, 560, 720, 900, 1100, 1280, 200, 450, 650, 830, 1050, 1300, 80, 980};
        int[] seedY = {30, 20, 40, 15, 35, 25, 18, 48, 38, 12, 44, 28, 10, 22, 42};
        for (int i = 0; i < seedX.length; i++) {
            int parpadeo = (f + i * 23) % 90;
            if (parpadeo < 70) g.fillOval(seedX[i], seedY[i], 3, 3);
        }

        // Bordes laterales tipo tribunas.
        g.setColor(new Color(45, 35, 65));
        g.fillRect(0, 0, 52, ConfiguracionJuego.ALTO_PANEL);
        g.fillRect(ConfiguracionJuego.ANCHO_PANEL - 52, 0, 52, ConfiguracionJuego.ALTO_PANEL);
        g.setColor(new Color(30, 20, 50));
        g.fillRect(52, 0, 12, ConfiguracionJuego.ALTO_PANEL);
        g.fillRect(ConfiguracionJuego.ANCHO_PANEL - 64, 0, 12, ConfiguracionJuego.ALTO_PANEL);

        dibujarPublico(g, f);

        // Malla superior e inferior.
        g.setColor(new Color(80, 60, 120, 60));
        int desp = f % 20;
        for (int x = -20; x < ConfiguracionJuego.ANCHO_PANEL + 20; x += 20) {
            g.drawLine(x + desp, 0, x + 10 + desp, 12);
            g.drawLine(x - desp, ConfiguracionJuego.ALTO_PANEL - 1, x + 10 - desp, ConfiguracionJuego.ALTO_PANEL - 12);
        }

        // Sombra del borde del campo.
        g.setColor(new Color(0, 0, 0, 80));
        g.fillRect(0, ConfiguracionJuego.CAMPO_Y_MIN - 14, ConfiguracionJuego.ANCHO_PANEL, 10);
        g.fillRect(0, ConfiguracionJuego.CAMPO_Y_MAX + 4, ConfiguracionJuego.ANCHO_PANEL, 10);
    }

    private void dibujarPublico(Graphics2D g, int f) {
        int gradasAlto = 48;
        g.setColor(new Color(20, 14, 42, 140));
        g.fillRect(64, 0, ConfiguracionJuego.ANCHO_PANEL - 128, gradasAlto);
        g.fillRect(64, ConfiguracionJuego.ALTO_PANEL - gradasAlto, ConfiguracionJuego.ANCHO_PANEL - 128, gradasAlto);

        // Puntos de colores simulando gente.
        int[][] paleta = {{220, 70, 180}, {80, 200, 255}, {255, 220, 50}, {120, 255, 140}};
        for (int x = 72; x < ConfiguracionJuego.ANCHO_PANEL - 72; x += 26) {
            int pulso = (int)(Math.sin((f + x) * 0.06) * 3.0);
            int ci = (x / 26) % paleta.length;
            g.setColor(new Color(paleta[ci][0], paleta[ci][1], paleta[ci][2], 160));
            g.fillOval(x, 10 + pulso, 8, 8);
            g.fillOval(x + 4, ConfiguracionJuego.ALTO_PANEL - 22 - pulso, 8, 8);
        }
    }

    // ===================== CANCHA =====================

    private void dibujarCancha(Graphics2D g, int f) {
        // Cesped principal verde oscuro.
        g.setColor(new Color(34, 110, 46));
        g.fillRect(ConfiguracionJuego.CAMPO_X_MIN - 6, ConfiguracionJuego.CAMPO_Y_MIN - 6,
            (ConfiguracionJuego.CAMPO_X_MAX - ConfiguracionJuego.CAMPO_X_MIN) + 12,
            (ConfiguracionJuego.CAMPO_Y_MAX - ConfiguracionJuego.CAMPO_Y_MIN) + 12);

        // Franjas de cesped alternadas.
        int desp = (f / 3) % 72;
        for (int x = ConfiguracionJuego.CAMPO_X_MIN - desp; x < ConfiguracionJuego.CAMPO_X_MAX; x += 72) {
            if (((x - ConfiguracionJuego.CAMPO_X_MIN) / 72 + 1) % 2 == 0) {
                g.setColor(new Color(28, 96, 40));
                g.fillRect(x, ConfiguracionJuego.CAMPO_Y_MIN - 6, 72,
                    (ConfiguracionJuego.CAMPO_Y_MAX - ConfiguracionJuego.CAMPO_Y_MIN) + 12);
            }
        }

        // Reflejo de luz cenital.
        g.setPaint(new GradientPaint(
            ConfiguracionJuego.ANCHO_PANEL / 2, ConfiguracionJuego.CAMPO_Y_MIN,
            new Color(255, 255, 255, 22),
            ConfiguracionJuego.ANCHO_PANEL / 2, ConfiguracionJuego.CAMPO_Y_MAX,
            new Color(255, 255, 255, 4)
        ));
        g.fillRect(ConfiguracionJuego.CAMPO_X_MIN, ConfiguracionJuego.CAMPO_Y_MIN,
            ConfiguracionJuego.CAMPO_X_MAX - ConfiguracionJuego.CAMPO_X_MIN,
            ConfiguracionJuego.CAMPO_Y_MAX - ConfiguracionJuego.CAMPO_Y_MIN);

        // Lineas blancas reglamentarias.
        g.setColor(Color.WHITE);
        g.setStroke(new BasicStroke(2.5f));
        g.drawRect(ConfiguracionJuego.CAMPO_X_MIN, ConfiguracionJuego.CAMPO_Y_MIN,
            ConfiguracionJuego.CAMPO_X_MAX - ConfiguracionJuego.CAMPO_X_MIN,
            ConfiguracionJuego.CAMPO_Y_MAX - ConfiguracionJuego.CAMPO_Y_MIN);
        g.drawLine(ConfiguracionJuego.ANCHO_PANEL / 2, ConfiguracionJuego.CAMPO_Y_MIN,
            ConfiguracionJuego.ANCHO_PANEL / 2, ConfiguracionJuego.CAMPO_Y_MAX);
        g.drawOval(ConfiguracionJuego.ANCHO_PANEL / 2 - 56, ConfiguracionJuego.ALTO_PANEL / 2 - 56, 112, 112);

        // Areas grandes.
        g.drawRect(ConfiguracionJuego.CAMPO_X_MIN, ConfiguracionJuego.Y_PORTERIA + 30, 110, ConfiguracionJuego.ALTO_PORTERIA - 60);
        g.drawRect(ConfiguracionJuego.CAMPO_X_MAX - 110, ConfiguracionJuego.Y_PORTERIA + 30, 110, ConfiguracionJuego.ALTO_PORTERIA - 60);
        // Areas chicas.
        g.drawRect(ConfiguracionJuego.CAMPO_X_MIN, ConfiguracionJuego.Y_PORTERIA + 50, 46, ConfiguracionJuego.ALTO_PORTERIA - 100);
        g.drawRect(ConfiguracionJuego.CAMPO_X_MAX - 46, ConfiguracionJuego.Y_PORTERIA + 50, 46, ConfiguracionJuego.ALTO_PORTERIA - 100);

        // Punto central y de penalti.
        g.setColor(new Color(255, 255, 255, 200));
        g.fillOval(ConfiguracionJuego.ANCHO_PANEL / 2 - 4, ConfiguracionJuego.ALTO_PANEL / 2 - 4, 8, 8);
        g.fillOval(ConfiguracionJuego.CAMPO_X_MIN + 95, ConfiguracionJuego.ALTO_PANEL / 2 - 4, 8, 8);
        g.fillOval(ConfiguracionJuego.CAMPO_X_MAX - 103, ConfiguracionJuego.ALTO_PANEL / 2 - 4, 8, 8);

        // Semiarcos de area.
        g.setColor(new Color(255, 255, 255, 90));
        g.setStroke(new BasicStroke(2f));
        g.drawArc(ConfiguracionJuego.CAMPO_X_MIN + 78, ConfiguracionJuego.ALTO_PANEL / 2 - 72, 68, 144, 300, 120);
        g.drawArc(ConfiguracionJuego.CAMPO_X_MAX - 146, ConfiguracionJuego.ALTO_PANEL / 2 - 72, 68, 144, 120, 120);

        // Porterias.
        dibujarPorteria(g, true);
        dibujarPorteria(g, false);
    }

    private void dibujarPorteria(Graphics2D g, boolean local) {
        int xMarco  = local ? ConfiguracionJuego.CAMPO_X_MIN - 18 : ConfiguracionJuego.CAMPO_X_MAX - 2;
        int yMarco  = ConfiguracionJuego.Y_PORTERIA + 8;
        int fondo   = 26;
        int anchoM  = 20;
        int altoM   = ConfiguracionJuego.ALTO_PORTERIA - 16;

        // Marco metalico plateado.
        g.setColor(new Color(210, 210, 230));
        g.fillRect(xMarco, yMarco, anchoM, altoM);
        g.fillRect(local ? xMarco - fondo : xMarco + anchoM, yMarco, fondo, altoM);

        // Red con cuadricula.
        g.setColor(new Color(200, 200, 220, 100));
        int xRed = local ? xMarco - fondo : xMarco + anchoM;
        for (int i = 0; i < altoM; i += 14) {
            g.drawLine(xMarco + (local ? 0 : anchoM), yMarco + i, xRed + (local ? fondo : 0), yMarco + i + 7);
        }
        for (int i = 0; i <= fondo; i += 8) {
            int xi = local ? xMarco - i : xMarco + anchoM + i;
            g.drawLine(xi, yMarco, xi, yMarco + altoM);
        }
    }

    // ===================== DECORACION =====================

    private void dibujarDecoración(Graphics2D g, int f) {
        // Nombre del torneo arriba.
        g.setFont(new Font("Dialog", Font.BOLD, 22));
        g.setColor(new Color(180, 140, 255));
        g.drawString("LIGA RELAMPA", 60, 42);
        g.setColor(new Color(80, 220, 255));
        g.drawString("COPA DEL BARRIO", ConfiguracionJuego.ANCHO_PANEL - 230, 42);

        // Sombra decorativa detras de los titulos.
        g.setColor(new Color(0, 0, 0, 70));
        g.fillRoundRect(58, 20, 196, 30, 10, 10);
        g.fillRoundRect(ConfiguracionJuego.ANCHO_PANEL - 232, 20, 226, 30, 10, 10);

        // Mensaje inferior con animacion de pulso.
        int pulso = (int)(Math.sin(f * 0.07) * 5.0);
        g.setColor(new Color(255, 210, 50));
        g.setFont(new Font("Dialog", Font.BOLD, 13));
        g.drawString("Juega limpio", 64, ConfiguracionJuego.ALTO_PANEL - 16);
        g.setColor(new Color(120, 255, 180));
        g.drawString("Respeta al rival", ConfiguracionJuego.ANCHO_PANEL - 178, ConfiguracionJuego.ALTO_PANEL - 16);

        g.setColor(new Color(180, 130, 255, 30));
        g.fillOval(90 + pulso, ConfiguracionJuego.ALTO_PANEL - 68, 52, 20);
        g.fillOval(ConfiguracionJuego.ANCHO_PANEL - 148 - pulso, ConfiguracionJuego.ALTO_PANEL - 68, 52, 20);
    }

    // ===================== ETIQUETAS JUGADORES =====================

    private void dibujarEtiquetasJugadores(Graphics2D g, MotorJuego motor) {
        g.setFont(new Font("SansSerif", Font.BOLD, 11));
        for (Jugador jugador : motor.getTodosJugadores()) {
            String nombre = jugador.getNombre();
            FontMetrics fm = g.getFontMetrics();
            int aw = fm.stringWidth(nombre);
            int ex = jugador.getX() + jugador.getAncho() / 2 - aw / 2;
            int ey = jugador.getY() - 8;
            g.setColor(new Color(0, 0, 0, 140));
            g.fillRoundRect(ex - 5, ey - 12, aw + 10, 15, 7, 7);
            g.setColor(new Color(240, 245, 255));
            g.drawString(nombre, ex, ey);
        }
    }

    // ===================== HUD =====================

    private void dibujarHUD(Graphics2D g, MotorJuego motor) {
        // Panel central del marcador (centrado en la parte superior).
        int panelW = 360, panelH = 64;
        int panelX = (ConfiguracionJuego.ANCHO_PANEL - panelW) / 2;
        int panelY = ConfiguracionJuego.CAMPO_Y_MIN - 2;

        g.setPaint(new GradientPaint(panelX, panelY, new Color(20, 14, 50, 220), panelX + panelW, panelY + panelH, new Color(40, 28, 70, 200)));
        g.fillRoundRect(panelX, panelY, panelW, panelH, 18, 18);
        g.setColor(new Color(160, 120, 255, 100));
        g.setStroke(new BasicStroke(1.5f));
        g.drawRoundRect(panelX, panelY, panelW, panelH, 18, 18);

        // Nombres de equipo y marcador.
        g.setFont(new Font("SansSerif", Font.BOLD, 13));
        g.setColor(new Color(120, 180, 255));
        g.drawString("AZUL", panelX + 18, panelY + 20);
        g.setColor(new Color(255, 100, 100));
        g.drawString("ROJO", panelX + panelW - 60, panelY + 20);

        // Marcador grande en el centro.
        String marcador = motor.getGolesLocal() + "  -  " + motor.getGolesRival();
        g.setFont(new Font("SansSerif", Font.BOLD, 30));
        FontMetrics fm = g.getFontMetrics();
        g.setColor(Color.WHITE);
        g.drawString(marcador, panelX + (panelW - fm.stringWidth(marcador)) / 2, panelY + 48);

        // Temporizador.
        String tiempo = motor.getTiempoFormateado();
        g.setFont(new Font("SansSerif", Font.BOLD, 14));
        int fr = motor.getFramesRestantesPartido();
        boolean urgente = fr < ConfiguracionJuego.FPS * 30 && (fr / 20) % 2 == 0;
        g.setColor(urgente ? new Color(255, 80, 80) : new Color(220, 210, 255));
        g.drawString(tiempo, panelX + (panelW - g.getFontMetrics().stringWidth(tiempo)) / 2, panelY + panelH + 18);

        // Panel lateral izquierdo (info local).
        dibujarPanelInfo(g, motor, true);
        // Panel lateral derecho (info rival).
        dibujarPanelInfo(g, motor, false);

        // Texto de saque central.
        if (motor.getTextoSaque() != null && !motor.getTextoSaque().isEmpty()) {
            String txt = motor.getTextoSaque();
            g.setFont(new Font("SansSerif", Font.BOLD, 16));
            FontMetrics fms = g.getFontMetrics();
            int tw = fms.stringWidth(txt);
            int tx = (ConfiguracionJuego.ANCHO_PANEL - tw) / 2;
            int ty = ConfiguracionJuego.CAMPO_Y_MIN + 30;
            g.setColor(new Color(0, 0, 0, 140));
            g.fillRoundRect(tx - 10, ty - 16, tw + 20, 22, 10, 10);
            g.setColor(new Color(255, 230, 80));
            g.drawString(txt, tx, ty);
        }
    }

    private void dibujarPanelInfo(Graphics2D g, MotorJuego motor, boolean esLocal) {
        int px = esLocal ? 10 : ConfiguracionJuego.ANCHO_PANEL - 210;
        int py = ConfiguracionJuego.CAMPO_Y_MIN - 2;
        g.setPaint(new GradientPaint(px, py, new Color(10, 10, 30, 180), px + 196, py + 90, new Color(20, 15, 50, 160)));
        g.fillRoundRect(px, py, 196, 90, 14, 14);
        g.setColor(new Color(100, 80, 180, 80));
        g.setStroke(new BasicStroke(1f));
        g.drawRoundRect(px, py, 196, 90, 14, 14);

        g.setFont(new Font("SansSerif", Font.PLAIN, 12));
        g.setColor(new Color(200, 200, 230));
        if (esLocal) {
            g.drawString("Posesion: " + motor.getPoseedorTexto(), px + 8, py + 18);
            g.drawString("Bonus: " + motor.getPuntosBonus() + " pts", px + 8, py + 36);
            g.drawString("Goleador: " + motor.getUltimoGoleador(), px + 8, py + 54);
            g.drawString("Altura: " + String.format("%.1f", motor.getBalon().getAltura()), px + 8, py + 72);
        } else {
            g.drawString("Meta: " + ConfiguracionJuego.META_GOLES + " goles", px + 8, py + 18);
            g.drawString("SPACE: pase  |  X: tiro", px + 8, py + 36);
            g.drawString("WASD / Flechas: mover", px + 8, py + 54);
            g.drawString("P: pausa  |  R: reiniciar", px + 8, py + 72);
        }
    }

    // ===================== OVERLAY ESTADO =====================

    private void dibujarOverlayEstado(Graphics2D g, EstadoJuego estado, String mensaje, MotorJuego motor) {
        if (estado == EstadoJuego.JUGANDO) return;

        String titulo, subtitulo, detalle;

        switch (estado) {
            case INICIO -> {
                titulo    = "COPA DEL BARRIO";
                subtitulo = "3 vs 3 — Liga Relampago";
                detalle   = "ENTER para jugar   |   P pausa   |   R reiniciar";
            }
            case PAUSADO -> {
                titulo    = "PAUSA";
                subtitulo = "El partido espera...";
                detalle   = "P para continuar   |   R para reiniciar";
            }
            case GOL -> {
                titulo    = "!GOL!";
                subtitulo = motor.getResumenUltimoGol().isEmpty()
                    ? (mensaje.isEmpty() ? "La jugada se reinicia" : mensaje)
                    : mensaje + "  —  " + motor.getUltimoGoleador();
                detalle   = "Marcador: " + motor.getGolesLocal() + " - " + motor.getGolesRival();
            }
            case VICTORIA -> {
                titulo    = "!VICTORIA!";
                subtitulo = "Marcador final: " + motor.getGolesLocal() + " - " + motor.getGolesRival();
                detalle   = "R para jugar de nuevo";
            }
            case DERROTA -> {
                titulo    = "DERROTA";
                subtitulo = "Resultado: " + motor.getGolesLocal() + " - " + motor.getGolesRival();
                detalle   = "R para la revancha";
            }
            case TIEMPO_AGOTADO -> {
                boolean empate = motor.getGolesLocal() == motor.getGolesRival();
                titulo    = empate ? "EMPATE" : (motor.getGolesLocal() > motor.getGolesRival() ? "!VICTORIA!" : "DERROTA");
                subtitulo = "Tiempo agotado — " + motor.getGolesLocal() + " - " + motor.getGolesRival();
                detalle   = "R para jugar de nuevo";
            }
            default -> {
                titulo    = "";
                subtitulo = mensaje;
                detalle   = "";
            }
        }

        // Fondo oscuro semitransparente.
        g.setColor(new Color(0, 0, 20, 200));
        g.fillRect(0, 0, ConfiguracionJuego.ANCHO_PANEL, ConfiguracionJuego.ALTO_PANEL);

        // Tarjeta principal centrada.
        int cx = 200, cy = 150, cw = 500, ch = 180;
        g.setPaint(new GradientPaint(cx, cy, new Color(45, 20, 90), cx + cw, cy + ch, new Color(20, 8, 55)));
        g.fillRoundRect(cx, cy, cw, ch, 22, 22);
        g.setColor(new Color(180, 130, 255, 160));
        g.setStroke(new BasicStroke(2f));
        g.drawRoundRect(cx, cy, cw, ch, 22, 22);

        // Titulo.
        g.setFont(new Font("SansSerif", Font.BOLD, 36));
        FontMetrics fmT = g.getFontMetrics();
        g.setColor(new Color(220, 200, 255));
        g.drawString(titulo, cx + (cw - fmT.stringWidth(titulo)) / 2, cy + 54);

        g.setFont(new Font("SansSerif", Font.PLAIN, 18));
        FontMetrics fmS = g.getFontMetrics();
        g.setColor(new Color(180, 200, 255));
        g.drawString(subtitulo, cx + (cw - fmS.stringWidth(subtitulo)) / 2, cy + 100);

        g.setFont(new Font("SansSerif", Font.BOLD, 14));
        FontMetrics fmD = g.getFontMetrics();
        g.setColor(new Color(140, 160, 220));
        g.drawString(detalle, cx + (cw - fmD.stringWidth(detalle)) / 2, cy + 140);

        // Mascota celebrando / triste.
        if (estado == EstadoJuego.GOL || estado == EstadoJuego.VICTORIA || estado == EstadoJuego.DERROTA || estado == EstadoJuego.TIEMPO_AGOTADO) {
            boolean feliz = estado == EstadoJuego.VICTORIA ||
                (estado == EstadoJuego.TIEMPO_AGOTADO && motor.getGolesLocal() >= motor.getGolesRival());
            dibujarMascota(g, cx + cw + 30, cy + 20, feliz);
        }

        // Creditos del autor.
        g.setColor(new Color(180, 180, 220, 180));
        g.setFont(new Font("SansSerif", Font.PLAIN, 12));
        String creditos = "Leonardo Alexander Rodriguez Valencia  |  Grupo 25A  |  Turno Matutino";
        FontMetrics fmC = g.getFontMetrics();
        g.drawString(creditos, (ConfiguracionJuego.ANCHO_PANEL - fmC.stringWidth(creditos)) / 2, ConfiguracionJuego.ALTO_PANEL - 14);
    }

    private void dibujarMascota(Graphics2D g, int cx, int cy, boolean feliz) {
        // Cuerpo morado.
        g.setColor(new Color(130, 60, 200));
        g.fillOval(cx - 22, cy + 28, 44, 38);
        // Cabeza.
        g.fillOval(cx - 20, cy, 40, 36);

        // Orejas.
        g.setColor(new Color(100, 30, 160));
        int[] oxIzq = {cx - 18, cx - 10, cx - 4};
        int[] oyIzq = {cy + 2, cy - 14, cy + 4};
        g.fillPolygon(oxIzq, oyIzq, 3);
        int[] oxDer = {cx + 4, cx + 10, cx + 18};
        int[] oyDer = {cy + 4, cy - 14, cy + 2};
        g.fillPolygon(oxDer, oyDer, 3);
        g.setColor(new Color(230, 170, 255));
        int[] ixIzq = {cx - 15, cx - 10, cx - 6};
        int[] iyIzq = {cy + 1, cy - 9, cy + 3};
        g.fillPolygon(ixIzq, iyIzq, 3);
        int[] ixDer = {cx + 6, cx + 10, cx + 15};
        int[] iyDer = {cy + 3, cy - 9, cy + 1};
        g.fillPolygon(ixDer, iyDer, 3);

        // Ojos.
        g.setColor(Color.WHITE);
        g.fillOval(cx - 14, cy + 9, 11, 10);
        g.fillOval(cx + 3,  cy + 9, 11, 10);
        g.setColor(new Color(30, 10, 60));
        g.fillOval(cx - 11, cy + 11, 6, 6);
        g.fillOval(cx + 5,  cy + 11, 6, 6);
        // Brillo en ojos.
        g.setColor(Color.WHITE);
        g.fillOval(cx - 10, cy + 12, 2, 2);
        g.fillOval(cx + 6,  cy + 12, 2, 2);

        // Nariz.
        g.setColor(new Color(255, 120, 200));
        g.fillOval(cx - 3, cy + 21, 7, 5);

        // Boca.
        g.setColor(new Color(30, 10, 60));
        g.setStroke(new BasicStroke(1.8f));
        if (feliz) {
            g.drawArc(cx - 8, cy + 24, 10, 7, 180, 180);
            g.drawArc(cx + 1, cy + 24, 10, 7, 180, 180);
        } else {
            g.drawArc(cx - 8, cy + 26, 10, 7, 0, 180);
            g.drawArc(cx + 1, cy + 26, 10, 7, 0, 180);
        }

        // Bigotes.
        g.setColor(new Color(255, 255, 255, 190));
        g.setStroke(new BasicStroke(1.2f));
        g.drawLine(cx - 4, cy + 23, cx - 20, cy + 20);
        g.drawLine(cx - 4, cy + 25, cx - 20, cy + 27);
        g.drawLine(cx + 4, cy + 23, cx + 20, cy + 20);
        g.drawLine(cx + 4, cy + 25, cx + 20, cy + 27);

        // Cola.
        g.setColor(new Color(100, 30, 160));
        g.setStroke(new BasicStroke(4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawArc(cx + 14, cy + 42, 24, 22, 270, 270);

        // Patas.
        g.setColor(new Color(130, 60, 200));
        g.fillRoundRect(cx - 18, cy + 60, 12, 8, 6, 6);
        g.fillRoundRect(cx + 6,  cy + 60, 12, 8, 6, 6);

        // Brazos arriba si es feliz.
        if (feliz) {
            g.setStroke(new BasicStroke(4f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.setColor(new Color(100, 30, 160));
            g.drawLine(cx - 20, cy + 38, cx - 34, cy + 20);
            g.drawLine(cx + 20, cy + 38, cx + 34, cy + 20);
        }
    }
}
